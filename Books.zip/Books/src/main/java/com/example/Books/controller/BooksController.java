package com.example.Books.controller;

import com.example.Books.model.Books;
import com.example.Books.service.BooksService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "/book")
public class BooksController {

    @Autowired
    BooksService booksService;

    @GetMapping("")
    private List<Books> getAllBooks() {
        return booksService.getAllBooks();
    }

    @GetMapping("/{bookid}")
    private Books getBooks(@PathVariable("bookid") int bookId) {
        return booksService.getBooksById(bookId);
    }

    @DeleteMapping("/{bookid}")
    private void deleteBook(@PathVariable("bookid") int bookId) {
        booksService.delete(bookId);
    }

    @PostMapping("")
    private int saveBook(@RequestBody Books books) {
        booksService.storeBook(books);
        return books.getBookId();
    }


    @PutMapping("")
    private Books updateBook(@RequestBody Books books) {
        booksService.update(books);
        return books;
    }

}




